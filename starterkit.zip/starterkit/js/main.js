$("document").ready(function() {
  // Your javascript goes here...
  
  
  
});