$("document").ready(function() {
  // Your javascript goes here...
  $("#click-me").click(function() {
    $("#box").fadeToggle();
  });
});